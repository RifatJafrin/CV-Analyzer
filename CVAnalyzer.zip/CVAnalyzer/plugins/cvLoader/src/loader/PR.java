package loader;

import gate.Document;
import gate.Factory;
import gate.ProcessingResource;
import gate.creole.AbstractLanguageAnalyser;
import gate.creole.ResourceInstantiationException;
import gate.creole.metadata.CreoleResource;

import java.io.File;
import java.io.FilenameFilter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;

@CreoleResource(name = "Annotor", comment = "Add a descriptive comment about this resource")
public class PR extends AbstractLanguageAnalyser implements ProcessingResource {
	final String CV_DOCUMENTS = System.getProperty("user.home")+"\\CV";
	
	
	/*
	 * Execute for all the documents in Gate (non-Javadoc)
	 * 
	 * @see gate.creole.AbstractProcessingResource#execute()
	 */
	public void execute() {
		Iterator<Document> iter = corpus.iterator();
		while (iter.hasNext()) {
			Document doc = (Document) iter.next();
			if (doc.getName().contains("job_") || doc.getName().contains("cv_")) {
				return;
			}
			doc.setName("job_" + doc.getName());
		}

		ArrayList<String> files = getInputFiles(CV_DOCUMENTS);
		for (String fileName : files) {
			try {
				Document doc = Factory.newDocument(new URL("file:" + fileName));
				doc.setName("cv_" + new File(fileName).getName());
				corpus.add(doc);

			} catch (ResourceInstantiationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	private ArrayList<String> getInputFiles(String directory) {
		ArrayList<String> files = new ArrayList<String>();
		boolean isWindows = true;

		// determine OS
		String OS = System.getProperty("os.name").toLowerCase();
		if (OS.indexOf("win") < 0) {
			isWindows = false;
		}

		// read the file names

		if (isWindows) {
			File dir = new File(directory);
			File[] listOfFiles = dir.listFiles(new FilenameFilter() {
				public boolean accept(File dir, String filename) {
					return true;
				} // filename.endsWith(".doc");
			});

			for (File file : listOfFiles) {
				files.add(file.getAbsolutePath());
			}

			// for unix machines
		} else {

		}

		return files;
	}

	

}
