package metadata;

import gate.Annotation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;


public class Job {
	
	public HashMap<String, ArrayList<Annotation>> job;
	public HashMap<String, Set<String>> requirements;
	
	public Job(){
		job= new HashMap<String, ArrayList<Annotation>>();	
		requirements = new HashMap<String, Set<String>>();
	}
	
	public void add(String key, Annotation annotation){
		if(!job.containsKey(key) || job.get(key)==null){
			job.put(key, new ArrayList<Annotation>());
		}
		job.get(key).add(annotation);
	}
	
	
	public void printAnnotation(){
		for(String requirement: job.keySet()){
			for(Annotation annotation:job.get(requirement)){
				System.out.println(annotation.getFeatures().get("string").toString());
			}
		}
	}
	
	public void filter(){
		for(String key: job.keySet()){
			for(Annotation annotation: job.get(key)){
				if(requirements.get(key)==null){
					requirements.put(key, new HashSet<String>());
				}
				requirements.get(key).add(annotation.getFeatures().get("string").toString());
				}
		}
	}
	
	public void print(){
		for(String key: requirements.keySet()){
			for(String value: requirements.get(key)){
				System.out.println("key:"+ key+ " = "+ value);
			}
		}
	}
	
	
	}
