package metadata;

import gate.Annotation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class CV {
	public HashMap<String, ArrayList<Annotation>> cv;
	public HashMap<String, Set<String>> requirements;
	public String name;

public String personName="";
public String email="";

	public CV(String name) {
		cv = new HashMap<String, ArrayList<Annotation>>();
		requirements = new HashMap<String, Set<String>>();
		this.name = name;
	}

	public void add(String key, Annotation annotation) {
		if (!cv.containsKey(key) || cv.get(key) == null) {
			cv.put(key, new ArrayList<Annotation>());
		}
		cv.get(key).add(annotation);
	}

	public String getName() {
		return name;
	}

	public void filter() {
		for (String key : cv.keySet()) {
			for (Annotation annotation : cv.get(key)) {
				if (requirements.get(key) == null) {
					requirements.put(key, new HashSet<String>());
				}
				requirements.get(key).add(
						annotation.getFeatures().get("string").toString());
			}
		}

	}

	public void printAnnotation() {
		for (String requirement : cv.keySet()) {
			for (Annotation annotation : cv.get(requirement)) {
				System.out.println(annotation.getFeatures().get("string")
						.toString());
			}
		}
	}

	public void print() {
		for (String key : requirements.keySet()) {
			for (String value : requirements.get(key)) {
				System.out.println("key:" + key + " = " + value);
			}
		}
	}

}
