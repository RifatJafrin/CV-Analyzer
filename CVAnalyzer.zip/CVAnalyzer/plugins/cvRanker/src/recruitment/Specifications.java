package recruitment;

import java.util.HashMap;

public class Specifications {

	static public HashMap<String, String> specifications= new HashMap<String, String>();

	static public void init(){//annotation, summary heading
		specifications.put("ExperienceYear", "Experience");
		specifications.put("Position", "Designation");
		specifications.put("ProgrammingLanguage", "ProgrammingLanguage");
		specifications.put("Technology", "Skills");
		specifications.put("Organization", "Misc");
		specifications.put("TechnicalSkill", "Skills");
		specifications.put("MinExperience", "Experience");
		specifications.put("Discipline", "Education");
		specifications.put("AcademicEducation", "Education");
		specifications.put("Location", "Misc");
		specifications.put("Address", "Misc");
		specifications.put("OtherSkill", "Skills");
		
		
	}
	
	
}
