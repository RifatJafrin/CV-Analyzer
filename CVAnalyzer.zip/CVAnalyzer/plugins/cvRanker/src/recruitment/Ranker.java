package recruitment;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import metadata.CV;
import metadata.Job;

public class Ranker {

	static public HashMap<String, Double> mapping = new HashMap<String, Double>();

	static public void init() {
		mapping.put("ExperienceYear", 7.0);
		mapping.put("Position", 10.0);
		mapping.put("ProgrammingLanguage", 7.0);
		mapping.put("Technology", 6.0);
		mapping.put("Organization", 3.0);
		mapping.put("TechnicalSkill", 3.5);
		mapping.put("OtherSkill", 2.0);
		mapping.put("Discipline", 6.5);
		mapping.put("AcademicEducation", 5.5);
		mapping.put("Location", 0.0);
		mapping.put("Address", 0.0);

	}

	static public String ranker(Job job, ArrayList<CV> cvs) {
		init();
		HashMap<CV, Double> temp = new HashMap<CV, Double>();

		for (String criteria : job.requirements.keySet()) {
			for (CV cv : cvs) {
				if (cv.requirements.containsKey(criteria)) {

					if (!temp.containsKey(cv)) {
						temp.put(cv, 0.0);
					}
					temp.put(
							cv,
							temp.get(cv)
									+ countMatch(criteria,
											(HashSet<String>) job.requirements
													.get(criteria),
											(HashSet<String>) cv.requirements
													.get(criteria))
									* mapping.get(criteria));
				}
			}
		}

		HashMap<String, Double> rankedList = new HashMap<String, Double>();
		for (CV cv : temp.keySet()) {
			rankedList.put(cv.getName().substring(3), temp.get(cv));
		}
		rankedList = Sorter.sortByComparator(rankedList);
		// Sorter.printMap(rankedList);
		StringBuilder name = new StringBuilder();
		for (String cvname : rankedList.keySet()) {
			name.append(cvname + " ");
			// System.out.println(cvname+ " "+ rankedList.get(cvname));
		}
		printSummary(temp, rankedList);
		
				return name.toString();
	}

	static public int countMatch(String jobCriteriaValue,
			HashSet<String> jobValues, HashSet<String> cvValues) {
		int count = 0;
		for (String jobValue : jobValues) {
			for (String cvValue : cvValues) {
				String job = jobValue.toLowerCase();
				String cv = cvValue.toLowerCase();
				if (job.equals(cv) || job.contains(cv) || cv.contains(job)) {
					count++;
				}
			}
		}

		return count;
	}

	static public void printSummary(HashMap<CV, Double> temp,
		HashMap<String, Double> rankedList) {
		StringBuilder report = new StringBuilder();
		report.append("<!DOCTYPE html><html><body  style=\"background-color:cyan;\"><div style=\"padding-left:5%;\">");
		report.append("<h2 style=\"text-align:center\">CV Analyzer Report</h2>");

		int count = 0;
		for (String cvName : rankedList.keySet()) {
			count++;
			for (CV cv : temp.keySet()) {
				if (cvName.equals(cv.getName().substring(3))) {
					report.append("<p> <B>Rank " + count + " : " + cvName
							+ "</B><BR>");
					report.append("Name : " + cv.personName + "<BR>");
					report.append("Email : " + cv.email + "<BR>");
					report.append("Key Features : <UL>");

					for (String annotType : Specifications.specifications
							.keySet()) {
						String reportType = Specifications.specifications
								.get(annotType);
						if (reportType.equals("Misc")
								|| !cv.requirements.containsKey(annotType)) {
							continue;
						}
						report.append("<li> " + annotType + " :");
						for (String keyword : cv.requirements.get(annotType)) {
							report.append(keyword + ", ");
						}
					}
				}
				report.append("</ul></p>");
			}
		}

		report.append("</div></body></html>");

		try {
			File file = new File(System.getProperty("user.home")
					+ "/CVAnalyzer.html");
			if (!file.exists()) {
				file.createNewFile();
			}

			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(report.toString());
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
