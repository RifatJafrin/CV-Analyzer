package recruitment;

import gate.Annotation;

import java.util.ArrayList;
import java.util.HashSet;

import metadata.CV;
import metadata.Job;

public class Matcher {

	static public boolean isMatch(String jobCriteriaValue, HashSet<String> cvValues){
		if(jobCriteriaValue==null) {
			return false;
		}
		if(cvValues==null){
			return false;
		}
		if(cvValues.contains(jobCriteriaValue)){
			return true;
		}
		for(String str: cvValues){
			if(str.equalsIgnoreCase(jobCriteriaValue) || 
					str.toLowerCase().contains(jobCriteriaValue.toLowerCase())|| 
							jobCriteriaValue.toLowerCase().contains(str.toLowerCase())){
				return true;
			}
		}
		
		return false;
	}
	
	
	static public void matcher(Job job, ArrayList<CV> cvs){
		for(String criteria: job.job.keySet()){
			for(CV cv: cvs){
				if(cv.cv.containsKey(criteria)){
					for(Annotation jobAnnotation: job.job.get(criteria)){
						String jobVal=jobAnnotation.getFeatures().containsKey("string")?jobAnnotation.getFeatures().get("string").toString():null;
						if(isMatch(jobVal, (HashSet)cv.requirements.get(criteria))){
							if(!jobAnnotation.getFeatures().containsKey("relatedCV")){
								jobAnnotation.getFeatures().put("relatedCV", new HashSet<String>());
							}
							((HashSet<String>)jobAnnotation.getFeatures().get("relatedCV")).add(cv.getName().substring(3));
						
						}
					}
				}
			}
		}
	}
	
	
	
}
