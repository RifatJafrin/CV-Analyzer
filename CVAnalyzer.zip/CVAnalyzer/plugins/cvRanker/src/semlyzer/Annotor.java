package semlyzer;

import gate.Annotation;
import gate.AnnotationSet;
import gate.Document;
import gate.ProcessingResource;
import gate.creole.AbstractLanguageAnalyser;
import gate.creole.metadata.CreoleResource;
import gate.util.InvalidOffsetException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;

import metadata.CV;
import metadata.Job;
import recruitment.Matcher;
import recruitment.Ranker;
import recruitment.Specifications;

@CreoleResource(name = "Annotor", comment = "Add a descriptive comment about this resource")
public class Annotor extends AbstractLanguageAnalyser implements
		ProcessingResource {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3728108314829485991L;

	/*
	 * Execute for all the documents in Gate (non-Javadoc)
	 * 
	 * @see gate.creole.AbstractProcessingResource#execute()
	 */
	public void execute() {
		Specifications.init();
		OpenCalaisAnnotation.init();

		ArrayList<Job> jobs = processJob();// normal print
		for (Job job : jobs) {
			job.filter();
			//job.print();

		}

		ArrayList<CV> cvs = processCV();// normal print
		for (CV cv : cvs) {
			cv.filter();
		//	cv.print();

		}

		Matcher.matcher(jobs.get(0), cvs);

		//Ranker.ranker(jobs.get(0), cvs);
		String ranked=Ranker.ranker(jobs.get(0), cvs);
		assignRanks(jobs.get(0), ranked);
		
	}

	public void assignRanks(Job job, String ranks){

		for(String type: job.job.keySet()){
			for(Annotation annotation: job.job.get(type)){
				annotation.getFeatures().put("sortedCV", ranks);
			}
		}
	}

	public Annotation setContentValue(Document document, Annotation annotation) {
		try {
			String content = document
					.getContent()
					.getContent(annotation.getStartNode().getOffset(),
							annotation.getEndNode().getOffset()).toString();

			annotation.getFeatures().put("string", content);
		} catch (InvalidOffsetException e) {
			e.printStackTrace();
		}
		return annotation;
	}

	public ArrayList<Job> processJob() {
		Iterator<Document> iter = corpus.iterator();

		ArrayList<Job> jobs = new ArrayList<Job>();
		while (iter.hasNext()) {
			Document doc = (Document) iter.next();
			if (doc.getName().contains("job_")) {
				Job job = new Job();
				AnnotationSet defaultAnnotSet = doc.getAnnotations();
				HashSet<Integer> seen = new HashSet<Integer>();
				
				for (String requirement : Specifications.specifications
						.keySet()) {
					Set<Annotation> annotations = new HashSet<Annotation>(
							defaultAnnotSet.get(requirement));
					Iterator<Annotation> it = annotations.iterator();
					while (it.hasNext()) {
						Annotation annotation= it.next();
						int startNode=annotation.getStartNode().getId();
						if(seen.contains(startNode)){
							doc.getAnnotations().remove(annotation);
						}else{
							seen.add(startNode);
							job.add(requirement, setContentValue(doc, annotation));
						}
						
					}
				}

				HashMap<String, ArrayList<Annotation>> openCalaisAnnots = OpenCalaisAnnotation
						.extractAnnotations(defaultAnnotSet.get("OpenCalais"));
				for (String type : openCalaisAnnots.keySet()) {// openCalaisAnnots
					for (Annotation annotation : openCalaisAnnots.get(type)) {
						int startNode=annotation.getStartNode().getId();
						if(seen.contains(startNode)){
							doc.getAnnotations().remove(annotation);
						}else{
							seen.add(startNode);
							job.add(type, setContentValue(doc, annotation));
						}
					}

				}
				jobs.add(job);
			}

		}

		return jobs;
	}

	private ArrayList<CV> processCV() {
		Iterator<Document> iter = corpus.iterator();

		ArrayList<CV> cvs = new ArrayList<CV>();
		while (iter.hasNext()) {
			Document doc = (Document) iter.next();
			if (doc.getName().contains("cv_")) {
				CV cv = new CV(doc.getName());

				AnnotationSet defaultAnnotSet = doc.getAnnotations();
				
				Set<Annotation> persons = new HashSet<Annotation>(
						defaultAnnotSet.get("Person"));
				Iterator<Annotation> personIt = persons.iterator();
				TreeMap<Integer, String> personList= new TreeMap<Integer, String>();
				while (personIt.hasNext()) {
					Annotation annotation= personIt.next();
					String content;
					try {
						content = doc
								.getContent()
								.getContent(annotation.getStartNode().getOffset(),
										annotation.getEndNode().getOffset()).toString();
						personList.put(annotation.getStartNode().getId(), content);
					} catch (InvalidOffsetException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}
				if(!personList.isEmpty()){
					cv.personName= new String(personList.get(personList.firstKey()));  
					personList.clear();
				}
				
				Set<Annotation> emails = new HashSet<Annotation>(
						defaultAnnotSet.get("Email"));
				Iterator<Annotation> emailIt = emails.iterator();
				TreeMap<Integer, String> emailList= new TreeMap<Integer, String>();
				while (emailIt.hasNext()) {
					Annotation annotation= emailIt.next();
					String content;
					try {
						content = doc
								.getContent()
								.getContent(annotation.getStartNode().getOffset(),
										annotation.getEndNode().getOffset()).toString();
						emailList.put(annotation.getStartNode().getId(), content);
					} catch (InvalidOffsetException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}
				if(!emailList.isEmpty()){
					cv.email= new String(emailList.get(emailList.firstKey()));  
					emailList.clear();
					}
				
				
				
				
				
				HashSet<Integer> seen = new HashSet<Integer>();
				
				for (String requirement : Specifications.specifications
						.keySet()) {
					Set<Annotation> annotations = new HashSet<Annotation>(
							defaultAnnotSet.get(requirement));
					Iterator<Annotation> it = annotations.iterator();
					while (it.hasNext()) {
						Annotation annotation= it.next();
						int startNode=annotation.getStartNode().getId();
						if(seen.contains(startNode)){
							doc.getAnnotations().remove(annotation);
						}else{
							seen.add(startNode);
							cv.add(requirement, setContentValue(doc, annotation));
						}
					}
				}

				HashMap<String, ArrayList<Annotation>> openCalaisAnnots = OpenCalaisAnnotation
						.extractAnnotations(defaultAnnotSet.get("OpenCalais"));
				for (String type : openCalaisAnnots.keySet()) {
					for (Annotation annotation : openCalaisAnnots.get(type)) {
						int startNode=annotation.getStartNode().getId();
						if(seen.contains(startNode)){
							doc.getAnnotations().remove(annotation);
						}else{
							seen.add(startNode);
							cv.add(type, setContentValue(doc, annotation));
						}
					}

				}
				cvs.add(cv);

			}
		}

		return cvs;

	}

}
