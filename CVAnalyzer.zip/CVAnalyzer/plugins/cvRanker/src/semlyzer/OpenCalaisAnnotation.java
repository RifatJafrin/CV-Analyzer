package semlyzer;

import gate.Annotation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

import recruitment.Specifications;

public class OpenCalaisAnnotation {

	static public HashMap<String, String> opencalais_specifications_mappings= new HashMap<String, String>();
	
	static public void init(){//calais _type, annotation (in specification)
		opencalais_specifications_mappings.put("ProgrammingLanguage", "ProgrammingLanguage");
		opencalais_specifications_mappings.put("Technology", "Technology");
		opencalais_specifications_mappings.put("Position", "Position");
		opencalais_specifications_mappings.put("OperatingSystem", "Technology");
		opencalais_specifications_mappings.put("Location", "Location");
		opencalais_specifications_mappings.put("IndustryTerm", "Technology");
		opencalais_specifications_mappings.put("PersonCareer", "Position");
		
	}
	
	
	static public HashMap<String, ArrayList<Annotation>> extractAnnotations(Set<Annotation> annotations){
		HashMap<String, ArrayList<Annotation>> opencalaisAnnotations= new HashMap<String, ArrayList<Annotation>>();
		for(Annotation annotation: annotations){
			String openCalaisType=annotation.getFeatures().get("_type").toString();
			if(opencalais_specifications_mappings.containsKey(openCalaisType)){
				String specKey=opencalais_specifications_mappings.get(openCalaisType);
				
				if(Specifications.specifications.containsKey(specKey)){
					if(opencalaisAnnotations.get(specKey)==null){
						opencalaisAnnotations.put(specKey, new ArrayList<Annotation>());
					}
					opencalaisAnnotations.get(specKey).add(annotation);
				}
			}
		}
		
		return opencalaisAnnotations;
	}
}
